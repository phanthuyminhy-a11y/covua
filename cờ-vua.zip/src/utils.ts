import { Player, Pairing, Round } from './types';

/**
 * Simple Swiss System Pairing Algorithm
 * 1. Sort players by score, then Buchholz (or rating if available)
 * 2. Handle bye for odd number of players
 * 3. Pair players with similar scores who haven't played each other
 */
export function generatePairings(players: Player[], roundNumber: number): Pairing[] {
  const pairings: Pairing[] = [];
  
  // Sort players by score (primary), then Buchholz, then rating (tie-breakers)
  // This ensures we try to pair players with similar scores first
  // Sort available players by score (primary), Buchholz, and rating
  let availablePlayers = [...players].sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (b.buchholz !== a.buchholz) return b.buchholz - a.buchholz;
    return (b.rating || 0) - (a.rating || 0);
  });

  // Handle Bye for odd number of players
  // Rule: Assigned to the lowest scoring player who has not yet had a bye
  if (availablePlayers.length % 2 !== 0) {
    // Find candidate for BYE starting from the bottom
    let byeIdx = -1;
    for (let i = availablePlayers.length - 1; i >= 0; i--) {
      if (!availablePlayers[i].hadBye) {
        byeIdx = i;
        break;
      }
    }
    
    // If everyone already had a bye (rare), just take the bottom one
    if (byeIdx === -1) byeIdx = availablePlayers.length - 1;
    
    const byePlayer = availablePlayers.splice(byeIdx, 1)[0];
    pairings.push({ 
      white: byePlayer, 
      black: null, 
      result: '1-0', // Bye counts as a win
    });
  }

  /**
   * canPlayColor: Strict FIDE constraints
   * 1. No more than 2 same colors in a row.
   * 2. Total difference between White and Black must not exceed 2.
   */
  function canPlayColor(player: Player, color: 'W' | 'B'): boolean {
    const history = player.colorHistory;
    const whites = history.filter(c => c === 'W').length;
    const blacks = history.filter(c => c === 'B').length;
    const diff = whites - blacks;

    // Total color balance constraint
    if (color === 'W' && diff >= 2) return false;
    if (color === 'B' && diff <= -2) return false;

    // Consecutive color constraint
    if (history.length >= 2) {
      const last1 = history[history.length - 1];
      const last2 = history[history.length - 2];
      if (last1 === color && last2 === color) return false;
    }

    return true;
  }

  /**
   * getColorPreferenceScore: Higher score means better fit for color assignment
   */
  function getColorPreferenceScore(whiteCand: Player, blackCand: Player): number {
    const wHistory = whiteCand.colorHistory;
    const bHistory = blackCand.colorHistory;
    
    const wWhites = wHistory.filter(c => c === 'W').length;
    const wBlacks = wHistory.filter(c => c === 'B').length;
    const bWhites = bHistory.filter(c => c === 'W').length;
    const bBlacks = bHistory.filter(c => c === 'B').length;
    
    let score = 0;
    
    // Rule: Equalize number of games played with each color
    if (wWhites < wBlacks) score += 2; // White candidate needs white
    if (bWhites > bBlacks) score += 2; // Black candidate needs black
    
    // Rule: Alternate colors from previous round
    if (wHistory.length > 0 && wHistory[wHistory.length - 1] === 'B') score += 1;
    if (bHistory.length > 0 && bHistory[bHistory.length - 1] === 'W') score += 1;
    
    return score;
  }

  /**
   * findPairs: Recursive search with score-group prioritization
   */
  function findPairs(remaining: Player[]): Pairing[] | null {
    if (remaining.length === 0) return [];

    const p1 = remaining[0];
    const rest = remaining.slice(1);

    // Try pairing p1 with every other player in order (sorted by score groups)
    for (let i = 0; i < rest.length; i++) {
       const p2 = rest[i];
       
       // Prohibition: Never pair the same opponents twice
       if (!p1.opponents.includes(p2.id)) {
         // Determine color preferences
         const scenarios = [
           { w: p1, b: p2 },
           { w: p2, b: p1 }
         ].sort((a, b) => getColorPreferenceScore(b.w, b.b) - getColorPreferenceScore(a.w, a.b));

         for (const s of scenarios) {
           if (canPlayColor(s.w, 'W') && canPlayColor(s.b, 'B')) {
             const nextRemaining = [...rest];
             nextRemaining.splice(i, 1);
             
             const subResult = findPairs(nextRemaining);
             if (subResult !== null) {
               return [{ white: s.w, black: s.b }, ...subResult];
             }
           }
         }
       }
    }
    return null;
  }

  const result = findPairs(availablePlayers);
  if (result) {
    pairings.push(...result);
  } else {
    // Last resort fallback if search fails (should not happen with standard tournament sizes/rounds)
    const fallback = [...availablePlayers];
    while (fallback.length >= 2) {
      pairings.push({ white: fallback.shift()!, black: fallback.shift()! });
    }
  }

  return pairings;
}

export function calculateBuchholz(players: Player[], allPlayers: Player[]): Player[] {
  return players.map(player => {
    // Buchholz defined as sum of scores of actual opponents played
    const buchholz = player.opponents.reduce((sum, oppId) => {
      const opponent = allPlayers.find(p => p.id === oppId);
      return sum + (opponent ? opponent.score : 0);
    }, 0);
    
    return { ...player, buchholz };
  });
}
